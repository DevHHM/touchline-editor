//! Stateful, address-free command API shared by stdio and local transports.
//! The transport owns authentication and serialization. This layer owns the
//! same retained baselines, preview tokens and guarded mutations as the UI.
use super::*;

#[derive(Default)]
pub(crate) struct ApiSession {
    bridge: Bridge,
}

impl ApiSession {
    pub(crate) fn handle(&mut self, value: Value) -> Value {
        let id = value.get("id").and_then(Value::as_u64).map_or(Value::Null, |id| json!(id));
        // Only a name from our static catalogue may enter diagnostics. Unknown
        // command names and malformed envelopes can contain arbitrary payloads.
        let log_command=value.get("command").and_then(Value::as_str)
            .and_then(|name|COMMANDS.iter().find(|command|command.name==name)).map(|command|command.name);
        let request = serde_json::from_value::<Request>(value);
        let response = request.map_err(anyhow::Error::from).and_then(|mut request| {
            if request.args.is_null() { request.args = json!({}); }
            ensure!(request.args.is_object(), "args must be a JSON object");
            ensure!(COMMANDS.iter().any(|command| command.name == request.command),
                "Unknown command: {}. Call capabilities for supported commands.", request.command);
            // Reads must not keep using an old save's cached identities either.
            // The mutation path also performs its own existing preflight check.
            if self.bridge.connection.enabled && self.bridge.live
                && !matches!(request.command.as_str(), "connect" | "load_snapshot" | "connection_poll" | "connection_reconnect" | "capabilities")
            {
                let observed = self.bridge.connection_poll();
                ensure!(matches!(request.command.as_str(), "status" | "summary") || self.bridge.live,
                    "FM session changed: {}. Call connection_poll and connection_reconnect, then read and preview again.", observed["reason"]);
            }
            self.bridge.dispatch(&request.command, &request.args)
        });
        match response {
            Ok(data) => json!({"id":id,"ok":true,"data":data}),
            Err(error) => {
                if let Some(command)=log_command {
                    crate::runtime_log::error("command",command,"Command failed",&error);
                } else {
                    crate::runtime_log::event("error","command","invalid_request","Malformed or unknown command rejected");
                }
                self.failure_reply(id,&error,log_command)
            },
        }
    }
    fn failure_reply(&self,id:Value,error:&anyhow::Error,command:Option<&str>)->Value {
        let mut response=json!({"id":id,"ok":false,"error":format!("{error:#}")});
        if matches!(command,Some("connect"|"connection_poll"|"connection_reconnect")) {
            response["diagnostic_context"]=json!(self.bridge.connection.diagnostic_context);
        }
        response
    }
}

struct Command {
    name: &'static str,
    effect: &'static str,
    description: &'static str,
    required: &'static str,
    optional: &'static str,
}

macro_rules! command {
    ($name:literal, $effect:literal, $description:literal, $required:literal, $optional:literal) => {
        Command { name:$name, effect:$effect, description:$description, required:$required, optional:$optional }
    };
}

const COMMANDS: &[Command] = &[
    #[cfg(feature = "fm27-health-experiment")]
    command!("injury_test_preview", "preview", "Local experiment only: inspect verified FM27 active injuries for one player; no writes. Requires explicit experiment environment opt-in.", "id", "backup_path"),
    #[cfg(feature = "fm27-health-experiment")]
    command!("injury_test_apply", "game_write", "Local experiment only: consume one injury test preview with a retained save backup. Native cleanup has no scalar undo. Never retries a call.", "token", ""),
    #[cfg(feature = "fm27-health-experiment")]
    command!("ban_test_preview", "preview", "Local experiment only: inspect the native FM27 all-bans list for one player; no writes.", "id", "backup_path"),
    #[cfg(feature = "fm27-health-experiment")]
    command!("ban_test_apply", "game_write", "Local experiment only: run the fixed native all-bans sequence and verify other health state. Requires a single-use preview and retained save backup.", "token", ""),
    #[cfg(feature = "fm27-transfer-experiment")]
    command!("transfer_test_preview", "preview", "Local experiment only: inspect one non-loan player's contract and strict direct source/destination rosters for the fixed zero-fee native route.", "player_id,destination_club_id", "backup_path"),
    #[cfg(feature = "fm27-transfer-experiment")]
    command!("transfer_test_apply", "game_write", "Local experiment only: consume a retained native transfer plan once. Completion requires new contract affiliation and both exact roster membership checks.", "token", ""),
    command!("capabilities", "read", "Discover supported commands, limits and safe edit workflows.", "", ""),
    command!("status", "read", "Connection and indexed record counts; also observes save changes.", "", ""),
    command!("summary", "read", "Alias of status.", "", ""),
    command!("connect", "session", "Connect to supported running FM and build the reusable index. No game writes.", "", ""),
    command!("connection_poll", "session", "Probe process/save identity; invalidate stale baselines and previews.", "", ""),
    command!("connection_reconnect", "session", "Rebuild the index after the monitor reports can_reconnect=true. No edit is replayed.", "", ""),
    command!("load_snapshot", "session", "Open a local snapshot strictly read-only, even if its original FM process still exists.", "path", ""),
    command!("refresh", "session", "Invalidate previews and refresh the live squad, or reload the snapshot.", "", ""),
    command!("search", "read", "Paged indexed search. City group is its actual nation name (discover with search_facets); player/staff group is the squad. Numeric field predicates use query_start/query_step instead.", "", "kind,query,club_id,group,offset,limit,sort,descending,filter"),
    command!("detail", "read", "Read a kind-qualified entity and editable fields; retain the baseline for preview.", "kind,id", ""),
    command!("overlay_detail", "read", "Fresh staff detail without replacing the editor's retained baseline.", "id", ""),
    command!("club_growth", "read", "Read club squad growth reference values and their limitations.", "club_id", ""),
    command!("field_catalog", "read", "Discover one matching entity's fields plus bounded verified column_fields metadata for the column chooser; column metadata has no player values or editability.", "kind", "id"),
    command!("search_facets", "read", "Discover actual roles, squad groups, football categories and primary nationality choices (nations: id/name/count; people only).", "kind", ""),
    command!("league_catalog", "read", "Browse indexed clubs by verified first-team league, league nation and football category. Includes every club once; missing/legacy links remain in an explicit unclassified group. Club references open existing Club detail. refresh=true re-reads verified live links without game writes.", "", "refresh"),
    command!("query_start", "session", "Start incremental advanced search; request fields and field ranges using catalogue keys.", "kind", "filter,club_id,query,fields,sort,sort_field,descending"),
    command!("query_step", "read", "Read the next bounded page. Continue until complete=true; inspect failed/errors.", "query_id", ""),
    command!("query_cancel", "session", "Discard an advanced-search cursor (latest cursor if omitted).", "", "query_id"),
    command!("compare", "read", "Compare up to four kind-qualified entities with fresh details.", "targets", ""),
    command!("resolve_targets", "read", "Resolve up to 10,000 references into found entities and missing references.", "targets", ""),
    command!("preview", "preview", "Prepare field edits against the retained detail baseline; never writes FM.", "kind,id,edits", ""),
    command!("apply", "game_write", "Consume a scalar preview token and execute existing backup/guard/readback transaction.", "token", ""),
    command!("history", "read", "Read sanitized scalar-edit receipts.", "", ""),
    command!("undo", "game_write", "Guarded undo of a receipt from the same unchanged session.", "receipt_id", ""),
    command!("batch_preview", "preview", "Prepare common rules for 1–200 explicit targets; returns actual changes and unchanged rows.", "targets,rules", ""),
    command!("batch_apply", "game_write", "Consume a batch preview token; guarded changes and receipts reuse the editor engine.", "token", ""),
    command!("batch_history", "read", "Read sanitized batch receipts.", "", ""),
    command!("batch_undo", "game_write", "Guarded undo of a batch receipt from the same session.", "receipt_id", ""),
    command!("freeze_preview", "preview", "Prepare fixed desired values for 1–50 targets, including already matching values.", "targets,rules", ""),
    command!("freeze_enable", "session", "Consume only a freeze preview token and retain desired values; does not itself write FM.", "token", ""),
    command!("freeze_status", "read", "Read retained freeze targets and completed write cycles.", "", ""),
    command!("freeze_tick", "game_write", "Explicitly run one guarded freeze cycle; no background ticks run automatically.", "", ""),
    command!("freeze_stop", "session", "Discard active freeze targets.", "", ""),
    command!("relation_detail", "read", "Read relations, career plans and per-item editability, retaining a baseline.", "kind,id", ""),
    command!("career_targets", "read", "Search engine-backed career targets: 3 club, 5 continent, 9 nation, 25 competition.", "object_type", "query,limit"),
    command!("relation_preview", "preview", "Prepare a supported relation/career operation against the retained baseline.", "kind,id,operation", ""),
    command!("relation_apply", "game_write", "Consume a relation preview and apply with native ownership checks and backup.", "token", ""),
    command!("relation_history", "read", "Read sanitized relation/career receipts and available undo status.", "", ""),
    command!("relation_undo", "game_write", "Guarded undo of a relation receipt from the same session.", "receipt_id", ""),
    command!("event_context", "read", "Read retained club/city/sponsor context and event draft defaults.", "club_id", ""),
    command!("event_preview", "preview", "Prepare a sponsorship/club/city scenario from retained event context. Money is GBP.", "club_id,draft", ""),
    command!("event_apply", "game_write", "Consume an event preview and apply existing guarded financial/city changes.", "token", ""),
    command!("event_save", "file_write", "Save a reviewed scenario locally without changing FM.", "token", ""),
    command!("event_history", "read", "Read sanitized event receipts.", "", ""),
    command!("event_undo", "game_write", "Guarded undo of an event receipt from the same session.", "receipt_id", ""),
    command!("staff_review_start", "session", "Start incremental staff recommendation review. Actual hiring interest is not confirmed.", "club_id", "max_candidates"),
    command!("staff_review_step", "read", "Continue staff review until complete, retaining partial results and failures.", "review_id", ""),
    command!("staff_review_cancel", "session", "Cancel staff review and return its partial results.", "review_id", ""),
    command!("name_localization_context", "read", "Read original names and installed localization suggestions for player IDs.", "player_ids", ""),
    command!("name_localization_preview", "preview", "Prepare Korean display-name file changes; input entries are {id,korean_name}.", "entries", ""),
    command!("name_localization_apply", "file_write", "Install a reviewed localization plan; confirmed=true required. Does not rewrite FM memory names.", "token,confirmed", ""),
    command!("name_localization_history", "read", "Read localization file receipts.", "", ""),
    command!("name_localization_undo", "file_write", "Undo reviewed localization files; confirmed=true required.", "id,confirmed", ""),
    command!("library_get", "read", "Read the local scouting/search-preset library.", "", ""),
    command!("library_put", "file_write", "Persist the complete validated local scouting/search-preset library.", "library", "expected"),
    command!("shortlist_update", "file_write", "Create, rename, delete, add to or remove from a local shortlist; rejects stale state. Does not change FM.", "expected,change", ""),
    command!("library_import", "read", "Read a library file for review; does not save it.", "path", ""),
    command!("fm_shortlist_import", "read", "Parse supported SI FMF/SLF/SSF shortlist files for review, with strict bounds. No library or game writes.", "path", ""),
    command!("fm_shortlist_export", "file_write", "Export one local Player/Staff list to a new FMF/SLF/SSF file; rejects mixed kinds and stale state. User must load in FM; FM27 runtime compatibility unverified.", "path,name,kind,expected", ""),
    command!("library_export", "file_write", "Export library or one named shortlist as Touchline JSON to a new path. Not an FM fmf/slf export.", "path", "name"),
    command!("export_snapshot", "file_write", "Write the native index to a new local file. Snapshot contains internal addresses; API entity responses do not.", "path", ""),
    command!("export_rows", "file_write", "Export 1–200 explicit entity references to a new CSV path.", "targets,path", ""),
];

pub(crate) fn capabilities() -> Value {
    let list = |s: &str| s.split(',').filter(|s| !s.is_empty()).map(str::to_string).collect::<Vec<_>>();
    json!({
        "api_version":"1.0",
        "engine":"Touchline",
        "engine_version":env!("CARGO_PKG_VERSION"),
        "profile":backend::PROFILE,
        "build_profiles":backend::profiles::ALL,
        "build_capabilities_source":"status.build_capabilities; recognized builds do not imply all editing features are supported",
        "request":{"id":"unsigned integer","command":"string","args":"object; defaults to {}"},
        "response":{"id":"request id or null","ok":"boolean","data":"on success","error":"on failure"},
        "kinds":["Player","Staff","Person","Club","City"],
        "indexed_search_sorts":["name","nationality","club","age","ca","pa","role"],
        "commands":COMMANDS.iter().map(|c|json!({"name":c.name,"effect":c.effect,"description":c.description,"required_args":list(c.required),"optional_args":list(c.optional)})).collect::<Vec<_>>(),
        "limits":{"request_bytes":MAX_LINE,"preview_ttl_seconds":TOKEN_TTL.as_secs(),"search_page":500,"batch_targets":200,"freeze_targets":50,"compare_targets":4,"query_cursors":4,"query_page_rows":200,"staff_review_cursors":2,"staff_review_candidates":20000},
        "types":{
            "EntityRef":{"kind":"Player|Staff|Person|Club|City","id":"u32"},
            "EntityRow":{"nationality":"primary nationality name; empty means unknown","nationality_id":"primary nation u32 ID|null; never inferred from club or secondary nationality"},
            "Edit":{"key":"editable key returned by detail","value":"finite number within field min/max"},
            "Rule":{"key":"editable key returned by detail","operation":"set|add|percent|at_least|at_most","value":"finite number"},
            "FieldRange":{"key":"field_catalog key","min":"number|null","max":"number|null"},
            "Filter":{"age_min":"u32|null","age_max":"u32|null","ca_min":"u16|null","ca_max":"u16|null","pa_min":"u16|null","pa_max":"u16|null","role":"string","club_query":"string","group":"string|null","nationality_id":"positive u32|null; exact primary nation ID from search_facets.nations; people only","football_category":"men|women|unknown|null","employed":"bool","unemployed":"bool","fields":"FieldRange[]; query_start only","conditions":"SearchCondition[0..64]; base filters AND ordered expression; AND before OR; missing values do not match any comparison"},
            "SearchCondition":{"enabled":"bool; default true","join":"and|or; first enabled join ignored","source":"entity|field|position","key":"entity: id/name/club/role/group/age/ca/pa/nationality_id/football_category/employed; field: verified field_catalog key; position: any (Player only)","op":"number: eq/ne/gte/lte/gt/lt/between; text: eq/ne/contains/not_contains; bool: eq/ne; position: gte only","value":"number|string|bool according to field; position: integer proficiency 1..20","value2":"number for between only; otherwise omitted or null","positions":"position source only: 1..14 unique verified position_* field keys; any >= value within this single condition; omitted for entity/field"},
            "RelationOperation":{"discriminator":"action","variants":["add_career_target","set_career_target","set_social_relation","add_social_relation","delete_social_relation","set_career_details","add_career_club","delete_career_plan","delete_favourite_club","delete_secondary_nationality","set_career_club","set_favourite_club","add_favourite_club","set_secondary_nationality","add_secondary_nationality","reuse_name"],"availability":"Read relation_detail first. Unknown/read-only types are not made editable by this API."}
        },
        "workflows":{
            "scalar_edit":["connect once","search","detail","preview with field keys","inspect changes and can_apply","apply token","history"],
            "batch_edit":["search or query_start/query_step","explicit targets, maximum 200 per batch","batch_preview","inspect all changes","batch_apply token"],
            "advanced_search":["field_catalog","query_start with filter.fields and requested fields","query_step repeatedly until complete=true","sort collected numeric field rows on client"],
            "relations":["relation_detail","relation_preview operation","inspect changes","relation_apply token"],
            "event":["event_context","event_preview draft","inspect deltas","event_apply token"],
            "save_reload":["connection_poll invalidates old state","wait until can_reconnect=true","connection_reconnect","search/detail again; never retry an old apply token"]
        },
        "semantics":{"arbitrary_memory_access":false,"game_saved_automatically":false,"offline_writes":false,"mutations_retried_automatically":false,"parallel_dispatch":false,"money_currency":"GBP","ca_rebalanced_automatically":false,"single_use_preview_tokens":true}
    })
}

#[cfg(test)]
mod tests {
    #[test]
    fn failed_connection_replies_include_only_observed_pe_metadata() {
        let mut session=super::ApiSession::default();
        let context=crate::backend::watch::DiagnosticContext::from_pe(0x12345678,0x12345000);
        session.bridge.connection.diagnostic_context=Some(context);
        let failure=anyhow::anyhow!("unsupported build");
        for command in ["connect","connection_poll","connection_reconnect"] {
            let response=session.failure_reply(serde_json::json!(42),&failure,Some(command));
            assert_eq!(response["diagnostic_context"],serde_json::to_value(context).unwrap());
            assert_eq!(response["ok"],false);
            assert_eq!(response["id"],42);
            assert_eq!(response.as_object().unwrap().len(),4);
        }
        for command in [Some("detail"),Some("preview"),Some("apply"),None] {
            assert!(session.failure_reply(serde_json::json!(42),&failure,command).get("diagnostic_context").is_none());
        }
        session.bridge.connection.diagnostic_context=None;
        assert!(session.failure_reply(serde_json::json!(42),&failure,Some("connect"))["diagnostic_context"].is_null());
    }
    use super::*;
    #[test]
    fn envelope_rejects_malformed_requests_and_unknown_commands() {
        let mut s=ApiSession::default();
        for request in [json!([]),json!({"command":"status"}),json!({"id":-1,"command":"status"}),json!({"id":1,"command":"status","address":123}),json!({"id":1,"command":"status","args":[]}),json!({"id":1,"command":"write_memory","args":{}})] {
            assert_eq!(s.handle(request)["ok"],false);
        }
        let response=s.handle(json!({"id":42,"command":"status"}));
        assert_eq!(response["id"],42);assert_eq!(response["ok"],true);assert_eq!(response["data"]["connected"],false);
    }
    #[test]
    fn unsupported_transfer_loan_and_heal_requests_leave_snapshot_and_previews_unchanged() {
        struct Scratch { root:PathBuf, path:PathBuf }
        impl Drop for Scratch {
            fn drop(&mut self) {
                if self.path.parent()==Some(self.root.as_path())
                    && self.path.file_name().is_some_and(|n|n.to_string_lossy().starts_with("touchline-unsupported-mutations-")) {
                    let _=std::fs::remove_dir_all(&self.path);
                }
            }
        }
        let root=std::fs::canonicalize(std::env::temp_dir()).unwrap();
        let nonce=std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_nanos();
        let scratch=Scratch {path:root.join(format!("touchline-unsupported-mutations-{}-{nonce}",std::process::id())),root};
        std::fs::create_dir(&scratch.path).unwrap();
        let (mut bridge,detail)=super::super::tests::fixture();
        let index_path=scratch.path.join("index.json");
        let detail_path=scratch.path.join("detail-Player-7.json");
        let index_before=serde_json::to_vec(bridge.index.as_ref().unwrap()).unwrap();
        let detail_before=serde_json::to_vec(&detail).unwrap();
        std::fs::write(&index_path,&index_before).unwrap();
        std::fs::write(&detail_path,&detail_before).unwrap();
        bridge.snapshot=Some(index_path.clone());
        let mut session=ApiSession {bridge};
        let preview=session.handle(json!({"id":1,"command":"preview","args":{"kind":"Player","id":7,"edits":[{"key":"ca","value":110}]}}));
        assert_eq!(preview["ok"],true);
        let token=preview["data"]["token"].as_str().unwrap();
        let state_before=(session.bridge.epoch,session.bridge.connection_generation,session.bridge.sequence);
        let uncreated=scratch.path.join("must-not-create.json");
        for (i,command) in ["force_transfer","staff_force_transfer","loan_create","loan_end","remove_injuries","remove_bans"].iter().enumerate() {
            assert!(!COMMANDS.iter().any(|item|item.name==*command));
            let response=session.handle(json!({"id":100+i,"command":command,"args":{
                "kind":"Player","id":7,"target_club_id":99,"path":uncreated,"token":token}}));
            assert_eq!(response["id"],100+i);
            assert_eq!(response["ok"],false);
            assert!(response["error"].as_str().unwrap().starts_with("Unknown command:"));
            assert!(response.get("data").is_none());
            assert_eq!(std::fs::read(&index_path).unwrap(),index_before);
            assert_eq!(std::fs::read(&detail_path).unwrap(),detail_before);
            assert_eq!(std::fs::read_dir(&scratch.path).unwrap().count(),2);
            assert!(!uncreated.exists());
            assert_eq!(serde_json::to_vec(session.bridge.index.as_ref().unwrap()).unwrap(),index_before);
            assert_eq!(serde_json::to_vec(session.bridge.details.get(&(EntityKind::Player,7)).unwrap()).unwrap(),detail_before);
            assert_eq!(session.bridge.snapshot.as_ref(),Some(&index_path));
            assert!(!session.bridge.live);
            assert_eq!((session.bridge.epoch,session.bridge.connection_generation,session.bridge.sequence),state_before);
            assert_eq!(session.bridge.pending.len(),1);
            assert!(session.bridge.pending.contains_key(token), "rejected request consumed the prior preview");
        }
    }
    #[test]
    fn offline_preview_and_apply_use_existing_baseline_and_single_use_guard() {
        let (bridge,_) = super::super::tests::fixture();
        let mut s=ApiSession{bridge};
        let preview=s.handle(json!({"id":1,"command":"preview","args":{"kind":"Player","id":7,"edits":[{"key":"ca","value":110}]}}));
        assert_eq!(preview["ok"],true);assert_eq!(preview["data"]["can_apply"],false);
        assert_eq!(preview["data"]["changes"][0]["before"],100.0);
        let response=s.handle(json!({"id":2,"command":"apply","args":{"token":preview["data"]["token"]}}));
        assert_eq!(response["ok"],false);assert!(response["error"].as_str().unwrap().contains("읽기 전용"));
        let response=s.handle(json!({"id":3,"command":"apply","args":{"token":preview["data"]["token"]}}));
        assert_eq!(response["ok"],false);assert!(response["error"].as_str().unwrap().contains("이미 사용"));
    }
    #[test]
    fn catalogue_matches_every_top_level_dispatch_arm() {
        use std::collections::BTreeSet;
        let sources=[include_str!("../bridge.rs"),include_str!("workspace.rs"),include_str!("relations.rs"),include_str!("staff_review.rs"),include_str!("name_localization.rs")];
        let mut discovered=BTreeSet::new();
        for source in sources {
            // Individual test-only fields/hooks may appear before dispatch;
            // stop at the test module rather than the first cfg attribute.
            for line in source.lines().take_while(|line|*line!="mod tests {").filter(|line|line.starts_with("            \"")&&line.contains("=>")) {
                let arm=line.split("=>").next().unwrap();
                for (i,quoted) in arm.split('"').enumerate() { if i%2==1 { discovered.insert(quoted); } }
            }
        }
        // include_str! sees feature-gated source arms even when this binary
        // intentionally excludes the local health experiment.
        if !cfg!(feature = "fm27-health-experiment") {
            discovered.remove("injury_test_preview");
            discovered.remove("injury_test_apply");
            discovered.remove("ban_test_preview");
            discovered.remove("ban_test_apply");
        }
        if !cfg!(feature = "fm27-transfer-experiment") {
            discovered.remove("transfer_test_preview");
            discovered.remove("transfer_test_apply");
        }
        let declared=COMMANDS.iter().map(|c|c.name).collect::<BTreeSet<_>>();
        assert_eq!(declared.len(),COMMANDS.len(),"Duplicate catalogue command");
        assert_eq!(declared,discovered);
        let mut s=ApiSession::default();
        assert_eq!(s.handle(json!({"id":5,"command":"capabilities"}))["data"],capabilities());
    }
    #[test]
    fn injury_experiment_commands_are_absent_without_the_build_feature() {
        for name in ["injury_test_preview", "injury_test_apply", "ban_test_preview", "ban_test_apply"] {
            assert_eq!(COMMANDS.iter().any(|command| command.name == name), cfg!(feature = "fm27-health-experiment"));
        }
        for name in ["transfer_test_preview", "transfer_test_apply"] {
            assert_eq!(COMMANDS.iter().any(|command| command.name == name), cfg!(feature = "fm27-transfer-experiment"));
        }
    }
    #[test]
    fn api_responses_do_not_expose_binding_addresses() {
        let (bridge,detail)=super::super::tests::fixture();
        let mut s=ApiSession{bridge};
        let view=s.bridge.detail_json(&detail);
        fn check(value:&Value) {
            match value {
                Value::Object(map)=>for (key,value) in map { assert!(!["address","base","binding","guards","original"].contains(&key.as_str()));check(value); },
                Value::Array(values)=>for value in values {check(value);},
                _=>{}
            }
        }
        check(&view);
        check(&s.handle(json!({"id":1,"command":"search","args":{"kind":"Player"}})));
    }
}
