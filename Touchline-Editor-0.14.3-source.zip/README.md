# Touchline Editor — 종합 실시간 에디터

FM27/검증된 FM26 빌드를 위한 Windows용 네이티브 편집기입니다. C# WPF 화면과 Rust 엔진으로 구성하며 Chrome·WebView·AI API 없이 실행합니다.

## 다운로드

[릴리스](https://github.com/DevHHM/touchline-editor/releases)에서 Windows ZIP 전체를 내려받아 새 폴더에 압축 해제한 뒤 루트의 `Touchline Editor.exe`를 실행하세요. app·engine 폴더를 함께 유지해야 합니다.

## 주요 기능

- 선수·스태프·구단·도시·기타 인물 검색과 상세 화면, 국적·소속·포지션·능력치 등의 상세 조건.
- 지원하는 CA·PA·기술·정신·피지컬·히든·포지션 및 구단 재정·도시 수치의 변경 검토·백업·적용·되돌리기.
- 스태프 직무 점수 계산과 검색, 구단 구성원·선수단 구분, 실제 초상화와 구단 문장.
- 관심명단 생성·관리·파일 내보내기, 최근 프로필·검색 기록, 화면 배율·글자 두께 설정.
- 자동 업데이트와 사용자 동의 후 공개 GitHub 이슈로 보내는 오류 보고.

읽기·편집 가능 범위는 FM 버전과 정확한 빌드에 따라 다릅니다. 앱이 표시하는 실제 지원 여부를 기준으로 사용하세요. 모든 FMRTE 기능을 구현한 프로그램은 아닙니다.

일반 라이브 수치 수정은 FM 재시작 없이 반영됩니다. FM 화면을 다시 열어 확인하고 게임에서 저장하세요. 스냅샷 모드는 오프라인 조회용이며 게임에 적용할 수 없습니다.

[0.14.3 변경점](distribution/RELEASE-0.14.3.ko.md) · [오류 공유 안내](distribution/DIAGNOSTICS.ko.md) · [로컬 API](reference/local-api.md)

## 개발

Rust 안정 버전, Windows x64용 .NET 10 SDK 및 Windows SDK가 필요합니다. `build-wpf.ps1`로 오프라인 검사와 휴대용 패키지를 빌드합니다. 실제 게임에 쓰는 검사는 기본 자동 검사에 포함하지 않습니다.
